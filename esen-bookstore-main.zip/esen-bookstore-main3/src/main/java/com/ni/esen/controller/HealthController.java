package com.ni.esen.controller;

import com.ni.esen.model.Book;
import com.ni.esen.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/health")
@RequiredArgsConstructor
public class HealthController {

    @GetMapping
    public ResponseEntity getStatus()
    {
        return ResponseEntity.ok().build();
    }

}
