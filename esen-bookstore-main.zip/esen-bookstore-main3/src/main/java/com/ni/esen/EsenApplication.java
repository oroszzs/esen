package com.ni.esen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsenApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsenApplication.class, args);
	}

}
