package com.ni.esen.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
public class Book {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String title;
  private String author;
  private String publisher;
  private LocalDate publicationDate;
  private double price;

  public void validate()
  {




 /*   int i = 0;
    if (i == 0)
    {
      throw new RuntimeException("Title cannot be empty!");
    }
*/

    if (title == null)
      throw new RuntimeException("Title cannot be empty!");
    else {
      if (title.length() > 100)
        throw new RuntimeException("Title is too long!");
    }

    //if (author.length()>200)
     // return;

    if (author == null)
      throw new RuntimeException("Author cannot be empty!");
    else {
      if (author.length()<1)
        throw new RuntimeException("Author cannot be empty!");

      if (author.length()>50)
        throw new RuntimeException("Author name too long!");
    }

    if (publisher == null)
      throw new RuntimeException("Publisher cannot be empty!");
    else {
      if (publisher.length()<1)
        throw new RuntimeException("Publisher cannot be empty!");

      if (publisher.length()>50)
        throw new RuntimeException("Publisher name too long!");
    }

    if (price < 0)
      throw new RuntimeException("Price %.2f cannot be lower than zero!".formatted(price));

    if (price > 9999999)
      throw new RuntimeException("Price %.2f cannot be lower than zero!".formatted(price));

    if (publicationDate.isBefore(LocalDate.parse("1700-01-01")))
    {
      throw new RuntimeException("The publicationDate (%s) is too old!".formatted(publicationDate));
    }

    LocalDate today = LocalDate.now();
    if (publicationDate.isAfter(today.plusYears(10)))
    {
      throw new RuntimeException("The publicationDate (%s) is too far!".formatted(publicationDate));
    }


  }
}
